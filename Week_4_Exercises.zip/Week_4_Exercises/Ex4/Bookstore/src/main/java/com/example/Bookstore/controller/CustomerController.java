package com.example.Bookstore.controller;


import com.example.Bookstore.enitity.Customer;
import com.example.Bookstore.repository.CustomerRepository;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerRepository customerRepository;

    @PostMapping("/json")
    public Customer createCustomerFromJson(@RequestBody Customer customer) {
        return customerRepository.save(customer);
    }

    @PostMapping("/form")
    public Customer createCustomerFromForm(HttpServletRequest request) {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPassword(password);

        return customerRepository.save(customer);
    }
}
