package com.example.BookstoreAPI.controller;


import com.example.BookstoreAPI.model.Author;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/authors")
public class AuthorController {

    private List<Author> authors = new ArrayList<>();

    @GetMapping
    public List<Author> getAllAuthors() {
        return authors;
    }

    @PostMapping
    public Author addAuthor(@RequestBody Author author) {
        authors.add(author);
        return author;
    }

    @GetMapping("/{id}")
    public Author getAuthorById(@PathVariable Long id) {
        return authors.stream()
                .filter(author -> author.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @PutMapping("/{id}")
    public Author updateAuthor(@PathVariable Long id, @RequestBody Author updatedAuthor) {
        Author author = authors.stream()
                .filter(a -> a.getId().equals(id))
                .findFirst()
                .orElse(null);

        if (author != null) {
            author.setName(updatedAuthor.getName());
            author.setBiography(updatedAuthor.getBiography());
        }

        return author;
    }

    @DeleteMapping("/{id}")
    public void deleteAuthor(@PathVariable Long id) {
        authors.removeIf(author -> author.getId().equals(id));
    }
}
