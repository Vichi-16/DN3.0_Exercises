package com.example.Bookstore.controller;


import org.springframework.web.bind.annotation.*;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private final Map<Long, String> customerDatabase = new HashMap<>();
    
    public CustomerController() {
        customerDatabase.put(1L, "Customer One");
        customerDatabase.put(2L, "Customer Two");
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getCustomerById(@PathVariable Long id) {
        String customer = customerDatabase.get(id);
        if (customer == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomerDetails");

        return new ResponseEntity<>(customer, headers, HttpStatus.OK);
    }
    
    @PostMapping
    public ResponseEntity<String> createCustomer(@RequestBody String customerName) {
        long newId = customerDatabase.size() + 1L;
        customerDatabase.put(newId, customerName);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomerCreated");

        return new ResponseEntity<>("Customer created with ID " + newId, headers, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {
        if (customerDatabase.remove(id) == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomerDeleted");

        return new ResponseEntity<>("Customer deleted", headers, HttpStatus.NO_CONTENT);
    }
}
