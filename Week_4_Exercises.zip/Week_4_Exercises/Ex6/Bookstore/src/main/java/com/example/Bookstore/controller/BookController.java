package com.example.Bookstore.controller;


import com.example.Bookstore.exception.InvalidInputException;
import com.example.Bookstore.exception.ResourceNotFoundException;
import com.example.Bookstore.model.Book;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        if (id <= 0) {
            throw new InvalidInputException("Invalid book ID");
        }

        Optional<Book> book = Optional.ofNullable(null); 

        if (book.isEmpty()) {
            throw new ResourceNotFoundException("Book not found");
        }

        return ResponseEntity.ok(book.get());
    }

}

