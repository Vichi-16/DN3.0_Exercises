package com.example.EmployeeManagement.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.EmployeeManagement.entity.Employee;
import com.example.EmployeeManagement.service.BatchEmployeeService;
import com.example.EmployeeManagement.service.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private BatchEmployeeService batchEmployeeService;

    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @PostMapping("/batch")
    public String createEmployeesInBatch(@RequestBody List<Employee> employees) {
        batchEmployeeService.saveEmployeesInBatch(employees);
        return "Batch processing completed!";
    }
}

