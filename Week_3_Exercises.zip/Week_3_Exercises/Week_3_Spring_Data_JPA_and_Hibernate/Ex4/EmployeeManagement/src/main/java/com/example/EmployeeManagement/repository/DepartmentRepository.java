package com.example.EmployeeManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagement.model.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
