package com.example.EmployeeManagement.repository;

import com.example.EmployeeManagement.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Query Method Example
    List<Employee> findByDepartment(String departmentName);
    
    List<Employee> findBySalaryGreaterThan(Double salary);
    
    List<Employee> findByLastNameStartingWith(String prefix);

    
    @Query("SELECT e FROM Employee e WHERE e.department = :departmentName")
    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);

    @Query("SELECT e FROM Employee e WHERE e.salary BETWEEN :minSalary AND :maxSalary")
    List<Employee> findEmployeesBySalaryRange(@Param("minSalary") Double minSalary, @Param("maxSalary") Double maxSalary);

    
    @Query(name = "Employee.findByDepartmentName")
    List<Employee> findEmployeesByNamedDepartmentName(@Param("departmentName") String departmentName);

    @Query(name = "Employee.findBySalaryGreaterThan")
    List<Employee> findEmployeesByNamedSalaryGreaterThan(@Param("salary") Double salary);
}
