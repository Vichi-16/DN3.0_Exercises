package com.example.EmployeeManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagement.entity.SecondaryEntity;

public interface SecondaryRepository extends JpaRepository<SecondaryEntity, Long> {
}
