package com.example.EmployeeManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagement.entity.PrimaryEntity;

public interface PrimaryRepository extends JpaRepository<PrimaryEntity, Long> {
}