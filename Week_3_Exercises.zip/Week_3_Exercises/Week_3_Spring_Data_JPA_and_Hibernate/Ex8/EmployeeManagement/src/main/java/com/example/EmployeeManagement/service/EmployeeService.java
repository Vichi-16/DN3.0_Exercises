package com.example.EmployeeManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.EmployeeManagement.projection.EmployeeDTO;
import com.example.EmployeeManagement.projection.EmployeeNameAndDepartment;
import com.example.EmployeeManagement.repository.EmployeeRepository;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public List<EmployeeNameAndDepartment> getEmployeeNamesAndDepartments() {
        return employeeRepository.findEmployeeNamesAndDepartments();
    }

    public List<EmployeeDTO> getEmployeeDetails() {
        return employeeRepository.findEmployeeDetails();
    }
}
