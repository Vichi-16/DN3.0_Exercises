package com.example.EmployeeManagement.projection;

public interface EmployeeNameAndDepartment {
    String getName();
    String getDepartmentName();
}
