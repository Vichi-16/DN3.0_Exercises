package com.example.EmployeeManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.EmployeeManagement.model.Employee;
import com.example.EmployeeManagement.projection.EmployeeDTO;
import com.example.EmployeeManagement.projection.EmployeeNameAndDepartment;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	@Query("SELECT e.name AS name, d.name AS departmentName FROM Employee e JOIN e.department d")
    List<EmployeeNameAndDepartment> findEmployeeNamesAndDepartments();

    @Query("SELECT new com.example.employeemanagement.projection.EmployeeDTO(e.name, d.name) FROM Employee e JOIN e.department d")
    List<EmployeeDTO> findEmployeeDetails();
    
}
