package com.example.EmployeeManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.EmployeeManagement.projection.EmployeeDTO;
import com.example.EmployeeManagement.projection.EmployeeNameAndDepartment;
import com.example.EmployeeManagement.service.EmployeeService;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/names-departments")
    public List<EmployeeNameAndDepartment> getEmployeeNamesAndDepartments() {
        return employeeService.getEmployeeNamesAndDepartments();
    }

    @GetMapping("/details")
    public List<EmployeeDTO> getEmployeeDetails() {
        return employeeService.getEmployeeDetails();
    }
}
