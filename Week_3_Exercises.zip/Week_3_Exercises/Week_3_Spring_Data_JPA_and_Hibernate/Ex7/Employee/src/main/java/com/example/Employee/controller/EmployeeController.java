package com.example.Employee.controller;

import com.example.Employee.model.Employee;
import com.example.Employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

 @Autowired
 private EmployeeService employeeService;

 @PostMapping
 public Employee createEmployee(@RequestBody Employee employee) {
     return employeeService.createEmployee(employee);
 }

 @PutMapping("/{id}")
 public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
     return employeeService.updateEmployee(id, employee);
 }

 @GetMapping
 public List<Employee> getAllEmployees() {
     return employeeService.getAllEmployees();
 }

 @DeleteMapping("/{id}")
 public void deleteEmployee(@PathVariable Long id) {
     employeeService.deleteEmployee(id);
 }
}

