package com.example.Employee.service;


import com.example.Employee.model.Employee;
import com.example.Employee.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

 @Autowired
 private EmployeeRepository employeeRepository;

 public Employee createEmployee(Employee employee) {
     return employeeRepository.save(employee);
 }

 public Employee updateEmployee(Long id, Employee updatedEmployee) {
     Employee existingEmployee = employeeRepository.findById(id)
             .orElseThrow(() -> new RuntimeException("Employee not found"));
     existingEmployee.setName(updatedEmployee.getName());
     return employeeRepository.save(existingEmployee);
 }

 public List<Employee> getAllEmployees() {
     return employeeRepository.findAll();
 }

 public void deleteEmployee(Long id) {
     employeeRepository.deleteById(id);
 }
}

