INSERT INTO employee (first_name, last_name, department, salary) VALUES ('John', 'Doe', 'HR', 60000);
INSERT INTO employee (first_name, last_name, department, salary) VALUES ('Jane', 'Smith', 'Finance', 70000);
INSERT INTO employee (first_name, last_name, department, salary) VALUES ('Robert', 'Brown', 'IT', 80000);
INSERT INTO employee (first_name, last_name, department, salary) VALUES ('Lucy', 'Wilson', 'Marketing', 50000);
