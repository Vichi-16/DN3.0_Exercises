//package Week1_Design_Patterns_and_Principles.Ex2;

public class WordDocument implements Document {
    @Override
    public void open() {
        System.out.println("Opening Word document...");
    }
}
