//package Week1_Design_Patterns_and_Principles.Ex2;

public class FactoryMethodTest {
    public static void main(String[] args) {
        
        DocumentFactory wordFactory = new WordDocumentFactory();
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();

        Document wordDocument = wordFactory.createDocument();
        Document pdfDocument = pdfFactory.createDocument();
        Document excelDocument = excelFactory.createDocument();

        
        wordDocument.open();
        pdfDocument.open();
        excelDocument.open();
    }
}
