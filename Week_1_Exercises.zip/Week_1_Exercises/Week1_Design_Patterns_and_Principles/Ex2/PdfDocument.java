//package Week1_Design_Patterns_and_Principles.Ex2;

public class PdfDocument implements Document {
    @Override
    public void open() {
        System.out.println("Opening PDF document...");
    }
}