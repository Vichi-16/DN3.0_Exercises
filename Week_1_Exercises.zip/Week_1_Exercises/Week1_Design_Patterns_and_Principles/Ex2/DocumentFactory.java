//package Week1_Design_Patterns_and_Principles.Ex2;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
