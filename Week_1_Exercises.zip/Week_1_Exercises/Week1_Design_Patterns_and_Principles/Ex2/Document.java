//package Week1_Design_Patterns_and_Principles.Ex2;

public interface Document {
    void open();
}
