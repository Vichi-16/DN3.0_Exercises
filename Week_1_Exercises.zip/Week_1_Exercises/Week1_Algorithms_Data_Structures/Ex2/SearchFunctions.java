

import java.util.Arrays;

class Product {
    int productId;
    String productName;
    String category;

    public Product(int productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }
}

public class SearchFunctions{
    
    public static Product linearSearch(Product[] products, int targetId) {
        for (Product product : products) {
            if (product.productId == targetId) {
                return product;
            }
        }
        return null; 
    }

    public static Product binarySearch(Product[] products, int targetId) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (products[mid].productId == targetId) {
                return products[mid];
            } else if (products[mid].productId < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return null; 
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(205, "Shoes", "Fashion"),
            new Product(309, "Smartphone", "Electronics"),
            new Product(415, "T-shirt", "Fashion"),
            new Product(512, "Headphones", "Electronics")
        };

        
        int targetId = 205;
        Product resultLinear = linearSearch(products, targetId);
        Product resultBinary = binarySearch(products, targetId);

        System.out.println("Linear Search Result: " + (resultLinear != null ? resultLinear.productName : "Not found"));
        System.out.println("Binary Search Result: " + (resultBinary != null ? resultBinary.productName : "Not found"));
    }
}


/* Analysis:
Time Complexity Comparison:

Linear Search: Best O(1), Worst O(n), Average O(n).
Binary Search: Best O(1), Worst O(log n), Average O(log n) (assuming the array is sorted). */