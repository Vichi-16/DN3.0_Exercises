public class TaskManagementSystem {
    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        taskList.addTask(new Task(1, "Design Database", "In Progress"));
        taskList.addTask(new Task(2, "Implement Authentication", "Not Started"));
        taskList.addTask(new Task(3, "Develop UI", "In Progress"));
        taskList.addTask(new Task(4, "Test Application", "Not Started"));

        System.out.println("All tasks:");
        taskList.traverseTasks();

        
        int searchId = 2;
        Task foundTask = taskList.searchTask(searchId);
        if (foundTask != null) {
            System.out.println("\nTask found with taskId " + searchId + ":");
            System.out.println(foundTask);
        } else {
            System.out.println("\nTask with taskId " + searchId + " not found.");
        }

        
        int deleteId = 1;
        taskList.deleteTask(deleteId);
        System.out.println("\nTasks after deleting task with taskId " + deleteId + ":");
        taskList.traverseTasks();
    }
}

