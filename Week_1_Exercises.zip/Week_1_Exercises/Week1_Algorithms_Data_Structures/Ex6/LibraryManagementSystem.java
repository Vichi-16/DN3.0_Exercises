import java.util.Arrays;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        
        Book[] books = {
            new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book(2, "1984", "George Orwell"),
            new Book(3, "To Kill a Mockingbird", "Harper Lee"),
            new Book(4, "Moby-Dick", "Herman Melville"),
            new Book(5, "Pride and Prejudice", "Jane Austen")
        };

        
        String titleToFind = "1984";
        Book foundBook = linearSearchByTitle(books, titleToFind);
        if (foundBook != null) {
            System.out.println("Linear Search - Book found: " + foundBook);
        } else {
            System.out.println("Linear Search - Book not found.");
        }

        
        Arrays.sort(books);

        
        titleToFind = "Moby-Dick";
        foundBook = binarySearchByTitle(books, titleToFind);
        if (foundBook != null) {
            System.out.println("Binary Search - Book found: " + foundBook);
        } else {
            System.out.println("Binary Search - Book not found.");
        }
    }

    
    public static Book linearSearchByTitle(Book[] books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static Book binarySearchByTitle(Book[] books, String title) {
        int left = 0;
        int right = books.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compareResult = books[mid].getTitle().compareToIgnoreCase(title);
            if (compareResult == 0) {
                return books[mid]; 
            }
            if (compareResult < 0) {
                left = mid + 1; 
            } else {
                right = mid - 1; 
            }
        }
        return null; 
    }
}
