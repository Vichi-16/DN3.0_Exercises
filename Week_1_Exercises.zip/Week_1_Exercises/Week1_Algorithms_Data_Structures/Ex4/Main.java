public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        ems.addEmployee(new Employee(1, "John Doe", "Manager", 75000));
        ems.addEmployee(new Employee(2, "Jane Smith", "Developer", 60000));
        ems.addEmployee(new Employee(3, "Emily Davis", "Designer", 55000));
        ems.addEmployee(new Employee(4, "Michael Brown", "Analyst", 58000));
        ems.addEmployee(new Employee(5, "Sarah Wilson", "Tester", 50000));
        
        System.out.println("All Employees:");
        ems.traverseEmployees();

        int searchId = 3;
        Employee emp = ems.searchEmployee(searchId);
        if (emp != null) {
            System.out.println("\nEmployee found: " + emp);
        } else {
            System.out.println("\nEmployee with ID " + searchId + " not found.");
        }

        int deleteId = 2;
        System.out.println("\nDeleting employee with ID " + deleteId);
        ems.deleteEmployee(deleteId);

        System.out.println("\nAll Employees after deletion:");
        ems.traverseEmployees();
    }
}

