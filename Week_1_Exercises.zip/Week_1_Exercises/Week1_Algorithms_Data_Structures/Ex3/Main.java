public class Main {
    public static void main(String[] args) {
        // Create an array of orders
        Order[] orders = {
            new Order(1, "Alice", 150.0),
            new Order(2, "Bob", 75.0),
            new Order(3, "Charlie", 200.0),
            new Order(4, "Diana", 125.0),
            new Order(5, "Edward", 50.0)
        };

        
        System.out.println("Orders before sorting:");
        printOrders(orders);

        Order[] bubbleSortedOrders = orders.clone(); 
        BubbleSort.bubbleSort(bubbleSortedOrders);
        System.out.println("\nOrders after Bubble Sort:");
        printOrders(bubbleSortedOrders);

        Order[] quickSortedOrders = orders.clone(); 
        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nOrders after Quick Sort:");
        printOrders(quickSortedOrders);
    }

    public static void printOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId() + ", Customer Name: " + order.getCustomerName() + ", Total Price: " + order.getTotalPrice());
        }
    }
}

