package com.example.onlinebookstore;

public class MyUserDetailsService {

}
