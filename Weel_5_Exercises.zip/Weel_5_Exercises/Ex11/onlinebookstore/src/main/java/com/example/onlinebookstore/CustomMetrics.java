package com.example.onlinebookstore;


import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;

import org.springframework.stereotype.Component;


@Component
public class CustomMetrics {

    private final MeterRegistry meterRegistry;

    public CustomMetrics(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @PostConstruct
    public void initMetrics() {
        meterRegistry.counter("custom.bookstore.requests", "type", "all").increment();
    }
}
