package com.example;

public interface BookRepository {
    void saveBook(String book);
    String findBook(String title);
}
