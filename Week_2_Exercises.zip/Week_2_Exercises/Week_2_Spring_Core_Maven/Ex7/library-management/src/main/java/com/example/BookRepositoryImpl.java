package com.example;

public class BookRepositoryImpl implements BookRepository {
    @Override
    public void saveBook(String book) {
        System.out.println("Saving book: " + book);
    }

    @Override
    public String findBook(String title) {
        return "Book details for: " + title;
    }
}
