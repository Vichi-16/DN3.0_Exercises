package com.library.repository;

public class BookRepository {

    public void findAllBooks() {
        System.out.println("Finding all books in the repository...");
    }
}
