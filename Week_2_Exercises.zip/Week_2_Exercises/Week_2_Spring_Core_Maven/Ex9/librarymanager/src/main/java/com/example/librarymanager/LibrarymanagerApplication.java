package com.example.librarymanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarymanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarymanagerApplication.class, args);
	}

}
