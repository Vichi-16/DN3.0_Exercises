package Main;
import com.library.service.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService bookService = (BookService) context.getBean("bookService");

        if (bookService != null) {
            System.out.println("BookService bean is successfully configured!");
        } else {
            System.out.println("BookService bean configuration failed.");
        }
    }
}
